'use client';

import { Code2, Cpu, Shield } from 'lucide-react';
import { useTheme } from '@/hooks/useTheme';
import { useState, useEffect } from 'react';
import { cn } from '@/lib/utils';

const features = [
  {
    name: 'Dijital Kampüs',
    description: 'Referans, online eğitim ile dünyanın her yerinden ulaşılabilir akademik deneyim sunar.',
    icon: Code2,
    darkColors: {
      bg: '#281a16',
      iconBg: '#131313',
      text: '#ff4d00'
    }
  },
  {
    name: 'Geleceğin Eğitimi',
    description: 'En güncel eğitim metotları ve öğrenme araçları, öğrencinin anlayarak öğrenmesini destekler.',
    icon: Cpu,
    darkColors: {
      bg: '#212019',
      iconBg: '#131313',
      text: '#8e8768'
    }
  },
  {
    name: 'Kişisel',
    description: 'Sana özel kurgulanmış eğitim programlarıyla başarı hikâyen şekilleniyor.',
    icon: Shield,
    darkColors: {
      bg: '#311c31',
      iconBg: '#131313',
      text: '#fc73ff'
    }
  },
];

const Content1 = () => {
  const { theme } = useTheme();
  const [mounted, setMounted] = useState(false);

  useEffect(() => {
    setMounted(true);
  }, []);

  return (
    <div className="py-32 sm:py-40">
      <div className="mx-auto max-w-7xl px-6 lg:px-8">
        <div className="max-w-3xl mx-auto text-center mt-0">
          <h2 className="text-xl sm:text-2xl font-semibold leading-7 text-primary">Ne öğrenmek istiyorsan</h2>
          <p className="mt-2 sm:mt-4 text-[2.5rem] sm:text-5xl lg:text-6xl font-bold tracking-tight text-foreground">
            Anlayarak öğren
          </p>
          <p className="mt-8 text-lg sm:text-xl lg:text-2xl leading-relaxed text-muted-foreground">
            Modern öğrenme metotları ile öğrenmek artık çok kolay ve etkili
          </p>
        </div>
        <div className="mt-16 sm:mt-20">
          <dl className="grid grid-cols-1 gap-12 sm:grid-cols-2 lg:grid-cols-3">
            {features.map((feature) => (
              <div 
                key={feature.name} 
                className="relative rounded-[24px] pl-8 pr-16 py-10 h-[320px] flex flex-col"
                style={mounted ? {
                  backgroundColor: theme === 'dark' ? feature.darkColors.bg : 'hsl(var(--muted))',
                } : undefined}
              >
                <dt>
                  <div 
                    className="flex h-11 w-fit items-center rounded-full px-4"
                    style={mounted ? {
                      backgroundColor: theme === 'dark' ? feature.darkColors.iconBg : 'hsl(var(--primary))',
                    } : undefined}
                  >
                    <div className="flex items-center gap-2">
                      <feature.icon 
                        className="h-8 w-8 stroke-[2.5]" 
                        style={mounted ? {
                          color: theme === 'dark' ? feature.darkColors.text : 'hsl(var(--primary-foreground))',
                        } : undefined}
                        aria-hidden="true" 
                      />
                      <span 
                        className="text-[19px] font-bold tracking-tight"
                        style={mounted ? {
                          color: theme === 'dark' ? feature.darkColors.text : 'hsl(var(--primary-foreground))',
                        } : undefined}
                      >{feature.name}</span>
                    </div>
                  </div>
                </dt>
                <dd 
                  className="mt-auto text-xl leading-7 font-medium"
                  style={mounted ? {
                    color: theme === 'dark' ? feature.darkColors.text : 'hsl(var(--muted-foreground))',
                  } : undefined}
                >
                  {feature.description}
                </dd>
              </div>
            ))}
          </dl>
        </div>
      </div>
    </div>
  );
};

export default Content1;